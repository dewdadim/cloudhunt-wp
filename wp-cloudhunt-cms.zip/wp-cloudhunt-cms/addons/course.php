<?php

//Create course post type
function register_course_post_type() {
    $args = [
        'label'  => esc_html__('Courses', 'text-domain'),
        'labels' => [
            'menu_name'          => esc_html__('Courses', 'cloudhunt-cms'),
            'name_admin_bar'     => esc_html__('Course', 'cloudhunt-cms'),
            'add_new'            => esc_html__('Add Course', 'cloudhunt-cms'),
            'add_new_item'       => esc_html__('Add new course', 'cloudhunt-cms'),
            'new_item'           => esc_html__('New Course', 'cloudhunt-cms'),
            'edit_item'          => esc_html__('Edit Course', 'cloudhunt-cms'),
            'view_item'          => esc_html__('View Course', 'cloudhunt-cms'),
            'update_item'        => esc_html__('View Course', 'cloudhunt-cms'),
            'all_items'          => esc_html__('All Courses', 'cloudhunt-cms'),
            'search_items'       => esc_html__('Search Courses', 'cloudhunt-cms'),
            'parent_item_colon'  => esc_html__('Parent Course', 'cloudhunt-cms'),
            'not_found'          => esc_html__('No Courses found', 'cloudhunt-cms'),
            'not_found_in_trash' => esc_html__('No Courses found in Trash', 'cloudhunt-cms'),
            'name'               => esc_html__('Courses', 'cloudhunt-cms'),
            'singular_name'      => esc_html__('Course', 'cloudhunt-cms'),
        ],
        'public'              => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'hierarchical'        => true,
        'has_archive'         => false,
        'query_var'           => false,
        'can_export'          => true,
        'rewrite_no_front'    => false,
        'show_in_menu'        => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-book',
        'taxonomies'          => array('category', 'post_tag'),
        'supports' => [
            'title',
            'author',
            'thumbnail',
            'revisions',
            'page_attribute'
        ],

        'rewrite' => true,

        'show_in_graphql'     => true,
        'graphql_single_name' => 'course',
        'graphql_plural_name' => 'courses',
    ];

    register_post_type('course', $args);
}
add_action('init', 'register_course_post_type');

//Add course meta box for add new course
function add_course_meta_box() {
    add_meta_box(
        'course_meta_box',
        'Course Details',
        'display_course_meta_box',
        'course',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_course_meta_box');

//The form for add new course
function display_course_meta_box($post) {
    wp_nonce_field('course_meta_box', 'course_meta_box_nonce');

    $title = get_post_meta($post->ID, '_course_title', true);
    $description = get_post_meta($post->ID, '_course_description', true);

    ?>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="course_description">Description</label>
                    </th>
                    <td>
                        <textarea id="cta_content" name="course_description" rows="3" cols="50" class="regular-text" required><?php echo esc_textarea($description); ?></textarea>
                    </td>
                </tr>
            </tbody>
        </table>
    <?php
}

//Add meta box for module to select course
function add_course_category_field($term) {
    $course = get_term_meta($term->term_id, 'course', true);
    ?>
        <tr class="form-field">
            <th scope="row"><label for="course">Course Box</label></th>
            <td>
                <?php course_select_option($course); ?>
            </td>
        </tr>
    <?php
}
add_action('category_edit_form_fields', 'add_course_category_field');

//Save the course
function save_course_category_field($term_id) {
    if (isset($_POST['course'])) {
        update_term_meta($term_id, 'course', $_POST['course']);
    }
}
add_action('edited_category', 'save_course_category_field');

//Save the course
function save_course_meta_box($post_id) {
    if (!isset($_POST['course_meta_box_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['course_meta_box_nonce'], 'course_meta_box')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = [
        '_course_title',
        '_course_description',
    ];

    foreach ($fields as $field) {
        $value = $_POST[ltrim($field, '_')] ?? '';
        update_post_meta($post_id, $field, $value);
    }
}
add_action('save_post', 'save_course_meta_box');

function course_add_post_metabox() {
    add_meta_box(
        'course_metabox',
        'Course',
        'display_course_post_metabox',
        'post',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'course_add_post_metabox');

function display_course_post_metabox($post) {
    wp_nonce_field('course_metabox', 'course_metabox_nonce');

    $course = get_post_meta($post->ID, '_course', true);
    course_select_option($course);
}

function course_select_option($value, $none_text = '-- Select Course --') {
    $courses = get_posts(['post_type' => 'course', 'numberposts' => -1]);

    ?>
        <select name="course">
            <option value=""><?php echo esc_html($none_text); ?></option>
            <?php foreach ($courses as $course): ?>
                <option value="<?php echo $course->ID; ?>" <?php selected($value, $course->ID); ?>><?php echo esc_html($course->post_title); ?> #<?php echo esc_html($course->ID); ?></option>
            <?php endforeach; ?>
        </select>
    <?php
}

function save_course_metabox($post_id) {
    if (!isset($_POST['course_metabox_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['course_metabox_nonce'], 'course_metabox')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['course'])) {
        update_post_meta($post_id, '_course', sanitize_text_field($_POST['course']));
    }
}
add_action('save_post', 'save_course_metabox');

// Register a custom taxonomy for modules
function register_module_taxonomy() {
    register_taxonomy('module', ['post', 'course'], [
        'label' => esc_html__('Modules', 'text-domain'),
        'rewrite' => ['slug' => 'module'],
        'hierarchical' => true,
        'show_in_graphql' => true, 
        'graphql_single_name' => 'Module', 
        'graphql_plural_name' => 'Modules',
    ]);
}
add_action('init', 'register_module_taxonomy');

// Modify the GraphQL registration to include modules under courses
add_action('graphql_register_types_late', function() {
    add_action('graphql_register_types', function() {
        register_graphql_object_type('Course', [
            'fields' => [
                'title' => ['type' => 'String'],
                'posts' => [
                    'type' => ['list_of' => 'Post'],
                    'resolve' => function ($course) {
                        return get_posts([
                            'post_type' => 'post',
                            'meta_query' => [
                                [
                                    'key' => '_course', // Assuming this is how posts link to courses
                                    'value' => $course->ID,
                                ],
                            ],
                        ]);
                    },
                ],
            ],
        ]);
    });
});